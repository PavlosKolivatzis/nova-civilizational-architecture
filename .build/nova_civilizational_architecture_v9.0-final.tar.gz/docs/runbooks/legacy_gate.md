# Legacy Gate Runbook (Archived)\n\nThis runbook targets the deprecated slots/ layout and is archived at rchive/legacy-slot-migration/runbooks/legacy_gate.md.
