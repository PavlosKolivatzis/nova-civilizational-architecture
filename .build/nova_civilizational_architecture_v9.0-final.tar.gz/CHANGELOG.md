# Changelog

## [Unreleased]

## [Released]

### v6.0 – Probabilistic Belief Propagation (Golden)
• Introduces uncertainty quantification and belief propagation between TRI↔Controls.
• Completes the Cognitive-Operational-Ethical Trinity.
• Adds Prometheus belief metrics and variance-based safety gates.