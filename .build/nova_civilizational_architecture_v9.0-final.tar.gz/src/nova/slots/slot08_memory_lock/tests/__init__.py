"""Test suite for Slot 8 Processual capabilities."""

# This file makes the tests directory a Python package