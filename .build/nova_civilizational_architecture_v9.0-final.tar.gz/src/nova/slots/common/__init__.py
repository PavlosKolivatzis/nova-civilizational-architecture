# slots/common package - shared utilities across Nova slots
