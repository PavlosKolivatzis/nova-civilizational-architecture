# Nova Civilizational Architecture - Reproducibility Kit
Version: v11.1-pre
Date: 2025-10-26T09:19:12.287505

## Quick Start

1. Install dependencies:
   pip install -r requirements.txt

2. Run the complete ARC calibration experiment:
   make reproduce-arc-experiment

3. Run ablation studies:
   make arc-ablation

4. Verify vault integrity:
   python scripts/verify_vault.py

## Contents

- Makefile: Complete experiment orchestration
- schemas/: JSON schema validation for results
- scripts/: Core experimental scripts
- src/nova/: Mathematical foundations and ARC implementation
- docs/: Complete documentation and experimental protocols

## Expected Results

After successful execution, you should observe:
- Precision >= 0.90 across 80% of calibration cycles
- Recall >= 0.90 across 80% of calibration cycles
- Drift <= 0.20 across 90% of calibration cycles
- Statistically significant improvement trends (p < 0.01)

## Citation

See CITATION.cff for proper attribution to the Nova Team.

## License

Apache-2.0
