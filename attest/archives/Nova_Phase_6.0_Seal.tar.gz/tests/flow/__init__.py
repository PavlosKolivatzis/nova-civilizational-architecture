"""
Flow Fabric Tests

Test suite for adaptive connections, flow metrics, and Flow Fabric components.
"""