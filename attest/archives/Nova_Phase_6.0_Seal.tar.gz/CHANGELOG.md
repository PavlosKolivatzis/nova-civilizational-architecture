# Changelog

## [Unreleased]

### v6.0 – Probabilistic Belief Propagation
• Adds uncertainty quantification and belief propagation across TRI↔Controls.
• Introduces variance-driven safety gates and Prometheus confidence metrics.
• Completes Cognitive-Operational-Ethical Trinity.