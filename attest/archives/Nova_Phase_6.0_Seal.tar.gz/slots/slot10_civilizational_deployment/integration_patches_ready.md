# Integration Patches

This legacy location remains for CI compatibility.
See `src/nova/slots/slot10_civilizational_deployment/integration_patches_ready.md` for the active document.
