# Nova Phase 1 Enhancements (Archived)\n\nSee rchive/legacy-slot-migration/Nova_Phase1_Enhancements_Compressed.md for the original deep-dive covering the legacy slots/ layout.
