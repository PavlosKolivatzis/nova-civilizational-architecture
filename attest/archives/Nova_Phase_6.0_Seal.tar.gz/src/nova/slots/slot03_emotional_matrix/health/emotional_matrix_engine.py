# slots/slot03_emotional_matrix/health/emotional_matrix_engine.py
# Thin re-export so tests can import/patch this path
from ..emotional_matrix_engine import EmotionalMatrixEngine

__all__ = ["EmotionalMatrixEngine"]