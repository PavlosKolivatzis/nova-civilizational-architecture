"""Nova slot namespace."""

from __future__ import annotations

import logging

memory_logger = logging.getLogger("memory")
